VOLUME 3 NO. 8 (JULY, 1982) 		MICR0-80			PAGE 21

			***** DR. WHO ADVENTURE *****

This adventure will just run on a MC-10 with the l6K Ram pack 
provided the following instructions are followed.
 
This is an unusual adventure, using two data files in a manner similar
to the Epyx games. The data files are called DRWHO1 and DRWHO2. They
were created using an initialization program.

For a cassette based system, use the following procedure:
All programs must be saved to tape in the order DRWHO, DRWHO1 and
DRWHO2.  Then CLOAD and run the adventure (DRWHO).  Press play on the
tape when prompted for the data files DRWHO1 and DRWHO2.  Make sure to
press stop after each file has loaded.

INSTRUCTIONS.

After Doctor Who collected the Key to Time and defeated the Black
Guardian, he received many praises and went on to greater things. The
Key itself was again broken into its component pieces and scattered
throughout the universe.  But dark forces threaten and in order to save
the universe, the Timelords once again need the Key. You have been
chosen to go forth and locate it for them. You will be given a TARDIS
(rather old and unreliable, but the best available) that has the
coordinates of the planets on which the six parts are located pre-programmed into it.
By RESETing its controls you can travel between the
six planets and Galafry. As usual, the six parts are disguised as other
things, and you will have to use your intuition to figure out which is
which. (There is a way to tell...)

All the planets are inhabited, and most inhabitants tend to be
antisocial. Whether you TALK to them, HIDE from them, kill them, OFFER
them gifts of appeasement, or simply ignore them is up to you. Most
objects are obvious, but some are hidden and have to be SEARCHed for.
Only one key part is on any one planet. Beware the maze on Peladon...

You can use commands of up to 64 characters. The program will ignore
any words it doesn't understand.  Commands can be one, two or three
words long.

When you find all the parts (or think you have), take them back to the
throne room on Galafry to win.

The program needs to re-read its data every time you start. You may
need to rewind the data tape to the beginning of DRWHO1 if you restart,
or hit BREAK.

Please report any bugs to Jim Gerrie at:
jimgerrie@ns.sympatico.ca



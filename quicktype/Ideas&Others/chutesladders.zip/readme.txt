**************  Chutes and Ladders v1.01  **************
*******************  By Steven Case  *******************

*Includes:
readme.txt (this file)
chutladr.89p (actual game)
clpic.89i (game board)
player1.89i (Player 1's game piece)
player2.89i (Player 2's game piece)
player3.89i (Player 3's game piece)
player4.89i (Player 4's game piece)
player5.89i (Player 5's game piece)

note: for this game to work the pictures must be in a folder called "pictures"

*Introduction:
This is an incredibly easy game to play.
All you have to do is select the number of players and press enter from there on out.

*History:
June 8, 2001 chutes and ladders is released
March 16, 2003 bug fixed

Please feel free to send coments, questions, and/or suggestions tome at
<stcinc@hotmail.com>
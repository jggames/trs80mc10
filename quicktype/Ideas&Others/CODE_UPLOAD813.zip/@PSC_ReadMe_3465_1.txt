Title: Stratego Game ( Easy Game Programming ! )
Description: This one is a great starting point for a nice little game like Stratego
in this exemple you can place an move your piece on the board, i utilize
the PaintPicture methode here with Picclip Control.
Nice graphics and nice code also so don't wait no more to get this code
yours By Planet-Source-Code ( VB Mania )
Thanks for using this code.
Carlos : elterrorista@videotron.ca
Please visit my new web site and see what you can do VB power !!! come and chat with me http://www.virtualgamer.t2u.com
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=3465&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
